package dto;

public class AddCourse {
	
	private String courseid,coursename,courseduration,instructorid;

	public AddCourse() {
		super();		
	}


	public String getCourseid() {
		return courseid;
	}

	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getCourseDuration() {
		return courseduration;
	}

	public void setCourseDuration(String courseduration) {
		this.courseduration= courseduration;
	}
	public String getInstructorid() {
		return instructorid;
	}

	public void setInstructorid(String instructorid) {
		this.instructorid = instructorid;
	}
	
	
	
	
	
	
}