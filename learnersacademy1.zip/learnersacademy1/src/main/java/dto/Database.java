package dto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Database {
    String url,username,password;
    
    Connection con;
    String query;
    Statement st;
    PreparedStatement pt;

    public Database() {
        super();
        this.url = "jdbc:mysql://127.0.0.1:3306/learners_academy";
        this.username = "root";
        this.password = "sumanth";
    }
    
    
    public void insert(StudentUser user) throws SQLException, ClassNotFoundException {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection(url, username, password);
        
        this.query = "insert into student_table values(?, ?, ?, ?, ?, ?, ?, ?)";
        
        pt = con.prepareStatement(query);
        
        pt.setString(1, user.getFirstname());
        pt.setString(2, user.getLastname());
        pt.setString(3, user.getEmail());
        pt.setString(4, user.getUsername());
        pt.setString(5, user.getPassword());
        pt.setString(6, user.getDateOfBirth());
        pt.setString(7, user.getGender());
        pt.setString(8, user.getStudentId());
        
        int row = pt.executeUpdate();
        
        if(row>0)
            System.out.println("insertion is success");
        
        con.close();        
    }

    public int validateStudent(String username, String password,String table) throws SQLException, ClassNotFoundException {
		
    	Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection(url, this.username, this.password);
		
		query = "select password from " + table + " where username='"+username+"'";
		
		//create statement
		st = con.createStatement();
		
		//execute statement
		ResultSet result = st.executeQuery(query);		
		
		if(!result.next()) {
			con.close();
			return 1;
		}
		if(result.getString(1).equals(password)) {
			con.close();
			return 2;
		}
		else {
			con.close();
			return 3;
		}
			
			
		//wrong uname
		//wrong password
		//correct uname and password
					
	}

    public StudentUser readStudent(String username,String table) throws SQLException, ClassNotFoundException {
    	
		//load the drive
		//create connection
    	Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection(url, this.username, this.password);
		
		//write query
		query = "select * from " + table +"  where username='"+username +"'";
		
		//create statement
		st = con.createStatement();
		
		//execute statement
		ResultSet result = st.executeQuery(query);
		StudentUser user = new StudentUser();
		//process the result(select)
		while(result.next()) {
			user.setFirstname(result.getString(1));
			user.setLastname(result.getString(2));
			user.setEmail(result.getString(3));
			user.setUsername(result.getString(4));
			user.setPassword(result.getString(5));
			user.setDateOfBirth(result.getString(6));
			user.setGender(result.getString(7));
			user.setStudentId(result.getString(8));
			
			
		}
		//close the connection
		con.close();
		return user;
	}


public void insert(InstructorUser user) throws SQLException, ClassNotFoundException {
    
    Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection(url, username, password);
    
    this.query = "insert into instructor_table values(?, ?, ?, ?, ?, ?, ?, ?)";
    
    pt = con.prepareStatement(query);
    
    pt.setString(1, user.getFirstname());
    pt.setString(2, user.getLastname());
    pt.setString(3, user.getEmail());
    pt.setString(4, user.getUsername());
    pt.setString(5, user.getPassword());
    pt.setString(6, user.getWorkExperience()); // Changed to getWorkExperience()
    pt.setString(7, user.getSubject());// Changed to getSubject()
    pt.setString(8, user.getInstructorId());
    
    int row = pt.executeUpdate();
    
    if(row > 0)
        System.out.println("insertion is success");
    
    con.close();        
}

public int validateInstructor(String username, String password,String table) throws SQLException, ClassNotFoundException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection(url, this.username, this.password);
	
	query = "select password from " + table + " where username='"+username+"'";
	
	//create statement
	st = con.createStatement();
	
	//execute statement
	ResultSet result = st.executeQuery(query);		
	
	if(!result.next()) {
		con.close();
		return 1;
	}
	if(result.getString(1).equals(password)) {
		con.close();
		return 2;
	}
	else {
		con.close();
		return 3;
	}
}

public InstructorUser readInstructor(String username,String table) throws SQLException, ClassNotFoundException {
	
	//load the driver
	//create connection
	Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection(url, this.username, this.password);
	
	//write query
	query = "select * from " + table +" where username='"+username +"'";
	
	//create statement
	st = con.createStatement();
	
	//execute statement
	ResultSet result = st.executeQuery(query);
	InstructorUser user = new InstructorUser();
	//process the result(select)
	while(result.next()) {
		user.setFirstname(result.getString(1));
		user.setLastname(result.getString(2));
		user.setEmail(result.getString(3));
		user.setUsername(result.getString(4));
		user.setPassword(result.getString(5));
		user.setWorkExperience(result.getString(6));
		user.setSubject(result.getString(7));
		user.setInstructorId(result.getString(8));
	}
	//close the connection
	con.close();
	return user;
}



public void insert(AdminUser user) throws SQLException, ClassNotFoundException {
    
    Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection(url, username, password);
    
    this.query = "insert into admin_table values(?, ?, ?, ?)";
    
    pt = con.prepareStatement(query);
    
    pt.setString(1, user.getAdminid());
    pt.setString(2, user.getUsername());
    pt.setString(3, user.getPassword());
    pt.setString(4, user.getDateofjoin());
    
    
    int row = pt.executeUpdate();
    
    if(row>0)
        System.out.println("insertion is success");
    
    con.close();        
}

public int validateAdmin(String username, String password, String table) throws SQLException, ClassNotFoundException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection(url, this.username, this.password);
	
	query = "select password from " + table + " where username='"+username+"'";
	
	//create statement
	st = con.createStatement();
	
	//execute statement
	ResultSet result = st.executeQuery(query);		
	
	if(!result.next()) {
		con.close();
		return 1;
	}
	if(result.getString(1).equals(password)) {
		con.close();
		return 2;
	}
	else {
		con.close();
		return 3;
	}
		
		
	//wrong uname
	//wrong password
	//correct uname and password
				
}

public AdminUser readAdmin(String username, String table) throws SQLException, ClassNotFoundException {
	
	//load the drive
	//create connection
	Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection(url, this.username, this.password);
	
	//write query
	query = "select * from " + table + " where username='"+username +"'";
	
	//create statement
	st = con.createStatement();
	
	//execute statement
	ResultSet result = st.executeQuery(query);
	AdminUser user = new AdminUser();
	//process the result(select)
	while(result.next()) {
		user.setAdminid(result.getString(1));
		user.setUsername(result.getString(2));
		user.setPassword(result.getString(3));
		user.setDateofjoin(result.getString(4));
		
		
		
	}
	//close the connection
	con.close();
	return user;
}

public void insert(AddCourse user) throws SQLException, ClassNotFoundException {
    
    Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection(url, username, password);
    
    this.query = "insert into course_table values(?, ?, ?, ?)";
    
    pt = con.prepareStatement(query);
    
    pt.setString(1, user.getCourseid());
    pt.setString(2, user.getCoursename());
    pt.setString(3, user.getCourseDuration());
    pt.setString(4, user.getInstructorid());
    
    
    int row = pt.executeUpdate();
    
    if(row > 0)
        System.out.println("insertion is success");
    
    con.close();        
}


public List<AddCourse> getAllCourses() throws SQLException, ClassNotFoundException {
    List<AddCourse> courses = new ArrayList<>();
    Connection con = null;
    PreparedStatement pt = null;
    ResultSet rs = null;

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection(url, username, password);

        String query = "SELECT * FROM course_table";
        pt = con.prepareStatement(query);

        rs = pt.executeQuery();

        while (rs.next()) {
            AddCourse course = new AddCourse();
            course.setCourseid(rs.getString("courseid"));
            course.setCoursename(rs.getString("coursename"));
            course.setCourseDuration(rs.getString("courseDuration"));
            course.setInstructorid(rs.getString("instructorid"));
            // Add more fields as needed
            courses.add(course);
        }
    } finally {
        // Close ResultSet, PreparedStatement, and Connection in finally block to ensure resources are released
        if (rs != null) {
            rs.close();
        }
        if (pt != null) {
            pt.close();
        }
        if (con != null) {
            con.close();
        }
    }

    return courses;
}




}