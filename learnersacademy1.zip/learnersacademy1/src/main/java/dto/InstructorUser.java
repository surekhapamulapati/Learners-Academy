package dto;

public class InstructorUser {
	
	private String firstname,lastname,email,username,password,workexperience,subject;
	private String instructorid;

	public InstructorUser() {
		super();		
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public String getWorkExperience() {
		return workexperience;
	}

	public void setWorkExperience(String workexperience) {
		this.workexperience = workexperience;
	}
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getInstructorId() {
		return instructorid;
	}

	public void setInstructorId(String instructorid) {
		this.instructorid = instructorid;
	}
	
	
	
	
	
	
}