package dto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CourseDatabase {
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/learners_academy";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "sumanth";

    public AddCourse getCourseDetails(String courseId) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            String query = "SELECT coursename, courseduration FROM course_table WHERE courseid = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, courseId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        AddCourse course = new AddCourse();
                        course.setCourseid(courseId); // Set the course ID from the parameter
                        course.setCoursename(resultSet.getString("coursename"));
                        course.setCourseDuration(resultSet.getString("courseduration"));
                        return course;
                    }
                }
            }
        }
        return null; // Return null if no course found with the provided ID
    }
}
