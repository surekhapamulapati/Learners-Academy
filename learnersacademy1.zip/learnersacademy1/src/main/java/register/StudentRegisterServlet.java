package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import dto.*;

@WebServlet("/studentregistration")
public class StudentRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  	
    	
    	StudentUser user = new StudentUser();
    	
    	user.setFirstname(request.getParameter("firstname"));
    	user.setLastname(request.getParameter("lastname"));
    	user.setEmail(request.getParameter("email"));
    	user.setUsername(request.getParameter("username"));
    	user.setPassword(request.getParameter("password"));
    	user.setDateOfBirth(request.getParameter("dateofbirth"));
    	user.setGender(request.getParameter("gender"));
    	user.setStudentId(request.getParameter("studentid"));
    	
    	Database db = new Database();
    	
    	try {
			db.insert(user);
			response.sendRedirect("success.jsp");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response.sendRedirect("error.jsp");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response.sendRedirect("error.jsp");
		}
	}

}