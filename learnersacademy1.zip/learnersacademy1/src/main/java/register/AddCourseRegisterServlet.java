package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import dto.*;

@WebServlet("/courseregistration")
public class AddCourseRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AddCourse user = new AddCourse();
        
        user.setCourseid(request.getParameter("courseid"));
        user.setCoursename(request.getParameter("coursename"));
        user.setCourseDuration(request.getParameter("courseduration"));
        user.setInstructorid(request.getParameter("instructorid"));
        Database db = new Database(); // Changed to Database2
        
        try {
            db.insert(user);
            // Redirect to a success page or do any other necessary action upon successful insertion
            response.sendRedirect("success.jsp"); // Example of redirection to a success page
        } catch (SQLException e) {
            e.printStackTrace();
            // Redirect to an error page or handle the error accordingly
            response.sendRedirect("error.jsp"); // Example of redirection to an error page
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            // Redirect to an error page or handle the error accordingly
            response.sendRedirect("error.jsp"); // Example of redirection to an error page
        }
    }
}