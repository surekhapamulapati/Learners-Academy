package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import dto.*;

@WebServlet("/instructorregistration")
public class InstructorRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        InstructorUser user = new InstructorUser();
        
        user.setFirstname(request.getParameter("firstname"));
        user.setLastname(request.getParameter("lastname"));
        user.setEmail(request.getParameter("email"));
        user.setUsername(request.getParameter("username"));
        user.setPassword(request.getParameter("password"));
        user.setWorkExperience(request.getParameter("workexperience")); // Changed to "workexperience"
        user.setSubject(request.getParameter("subject"));
        user.setInstructorId(request.getParameter("instructorid"));
        
        Database db = new Database(); // Changed to Database2
        
        try {
            db.insert(user);
            // Redirect to a success page or do any other necessary action upon successful insertion
            response.sendRedirect("success.jsp"); // Example of redirection to a success page
        } catch (SQLException e) {
            e.printStackTrace();
            // Redirect to an error page or handle the error accordingly
            response.sendRedirect("error.jsp"); // Example of redirection to an error page
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            // Redirect to an error page or handle the error accordingly
            response.sendRedirect("error.jsp"); // Example of redirection to an error page
        }
    }
}