package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import dto.*;

@WebServlet("/enrollment")
public class EnrollmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String courseId = request.getParameter("courseId");
        CourseDatabase courseDatabase = new CourseDatabase();

        try {
            AddCourse course = courseDatabase.getCourseDetails(courseId);
            if (course != null) {
                // Populate the enrollment form fields with the fetched course details
                request.setAttribute("courseId", courseId);
                request.setAttribute("courseName", course.getCoursename());
                request.setAttribute("courseDuration", course.getCourseDuration());
                request.getRequestDispatcher("instructorcourses.jsp").forward(request, response);
            } else {
                // Handle case where course ID is not found
                request.setAttribute("error", "Course not found for ID: " + courseId);
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error retrieving course details");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}


 



