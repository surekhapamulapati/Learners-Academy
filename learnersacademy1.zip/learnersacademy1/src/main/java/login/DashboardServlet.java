package login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import dto.Database;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null || session.getAttribute("usertype") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String username = (String) session.getAttribute("username");
        String userType = (String) session.getAttribute("usertype");
        
        try {
            Database db = new Database();
            switch (userType) {
                case "student_table":
                    request.setAttribute("user", db.readStudent(username, userType));
                    
                    request.getRequestDispatcher("studentdashboard.jsp").forward(request, response);
                    break;
                case "instructor_table":
                    request.setAttribute("user", db.readInstructor(username, userType));
                    
                    request.getRequestDispatcher("instructordashboard.jsp").forward(request, response);
                    break;
                case "admin_table":
                    request.setAttribute("user", db.readAdmin(username, userType));
                    
                    request.getRequestDispatcher("admindashboard.jsp").forward(request, response);
                    break;
                default:
                    response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred. Please try again later.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}