package login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import dto.Database;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Database db = new Database();
        String userType = request.getParameter("userType");

        try {
            int result = 0;
            if (userType.equals("student_table")) {
                result = db.validateStudent(request.getParameter("username"), request.getParameter("password"), userType);
            } else if (userType.equals("instructor_table")) {
                result = db.validateInstructor(request.getParameter("username"), request.getParameter("password"), userType);
            } else if (userType.equals("admin_table")) {
                result = db.validateAdmin(request.getParameter("username"), request.getParameter("password"), userType);
            }

            switch (result) {
                case 1:
                    session.setAttribute("error", "Username is wrong");
                    response.sendRedirect("login.jsp");
                    break;
                case 2:
                    session.setAttribute("username", request.getParameter("username"));
                    session.setAttribute("usertype", userType);
                    response.sendRedirect("dashboard");
                    break;
                case 3:
                    session.setAttribute("error", "Password is wrong");
                    response.sendRedirect("login.jsp");
                    break;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            session.setAttribute("error", "An error occurred. Please try again later.");
            response.sendRedirect("login.jsp");
        }
    }
}